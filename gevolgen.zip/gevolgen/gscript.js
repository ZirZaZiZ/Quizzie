const questions = [
    
    {
        question: 'Hoeveel slachtoffers telde de eerste wereldoorlog?',
        options: ['20 miljoen', '30 miljoen', '40 miljoen', '50 miljoen'], 
        correctAnswer: '30 miljoen',
        type: 'multiple-choice'
    },

    {
        question: 'Hoe heette het vredesverdrag dat na WO1 ondertekend is?',
        options: ['Verdrag van Versailles', 'Verdrag van Andelot', 'Verdrag van Ribemont', 'Verdrag van Spiers'], 
        correctAnswer: 'Verdrag van Versailles',
        type: 'multiple-choice'
    },

    {
        question: 'Wat stond er NIET in dit verdrag?',
        options: ['Duitse militaire besprekingen moeten gecontroleerd worden', 'Duitsland moet veel geld betalen door de schade', 'Het Duitse leger mag maximaal uit 100.000 man bestaan', 'Duitsland moet grondgebied afstaan'], 
        correctAnswer: 'Duitse militaire besprekingen moeten gecontroleerd worden',
        type: 'multiple-choice'
    },

    {
        question: 'Wat was een belangrijke vooruitgang in Nederland na aanleiding van WO1?',
        options: ['Homohuwelijk werd legaal', 'de NAVO werd gevormt', 'Algemeen kiesrecht werd ingevoerd', 'Er kwam veel vooruitgang in de economie'], 
        correctAnswer: 'Algemeen kiesrecht werd ingevoerd',
        type: 'multiple-choice'
    },

    {
        question: 'Tegen het einde van WO1 was er een revolutionaire stemming. Wat was hier een gevolg van?',
        options: ['De voormalige Duitse keizer werd vermoord', 'De Russische tsaar werd vermoord', 'De koning van Frankrijk werd afgezet', 'De koningin van Nederland werd afgezet'], 
        correctAnswer: 'De Russische tsaar werd vermoord',
        type: 'multiple-choice'
    },

    {
        question: 'De inflatie in Duitsland was verschrikkelijk in 1922. 1 Dollar kostte namelijk......',
        options: ['5000 Mark', '10000 Mark', '20000 Mark', '25000 Mark'], 
        correctAnswer: '20000 Mark',
        type: 'multiple-choice'
    },

    {
        question: 'Om de economische situatie te verbeteren werd er een nieuwe munt ingevoerd in Duitsland. Hoe heette deze munt?',
        options: ['Rentemark', 'Kostenmark', 'Uitermark', 'Intermark'], 
        correctAnswer: 'Rentemark',
        type: 'multiple-choice'
    },

    {
        question: 'Na WO1 gebeurde de zogenaamde "beurskrach". Wat werd hiermee bedoeld?',
        options: ['Het was nu mogenlijk om te beleggen in aandelen', 'De beurs zag een enorme vooruitgang', 'Het was niet meer mogenlijk om te beleggen in aandelen.', 'De beurs stortte in'], 
        correctAnswer: 'De beurs stortte in',
        type: 'multiple-choice'
    },

    {
        question: 'Hoe heette het Amerikaanse plan om Duitsland terug overeind te helpen?',
        options: ['Darwinplan', 'Dawesplan', 'Dalesplan', 'Daysplan'], 
        correctAnswer: 'Dawesplan',
        type: 'multiple-choice'
    },

    {
        question: 'In welk jaar begon de tweede wereldoorlog?',
        options: ['1938', '1939', '1940', '1941'], 
        correctAnswer: '1939',
        type: 'multiple-choice'
    },


    {
        question: 'De uitvinding van de radio had een onbedoeld gevolg. De radio werd ook gebruikt voor....',
        correctAnswer: 'propaganda',
        type: 'open-ended'
    },

    {
        question: 'Welke ideologie kwam aan de macht in Rusland na WO1?',
        correctAnswer: 'communisme',
        type: 'open-ended'
    },

    {
        question: 'Welke ideologie kwam aan de macht in Duitsland na WO1?',
        correctAnswer: 'Fascisme',
        type: 'open-ended'
    },

    {
        question: 'Het "Duitse rijk" stond nu bekend onder een andere naam. Het was nu een republiek. Hoe heette deze republiek? ',
        correctAnswer: 'Weimarrepubliek',
        type: 'open-ended'
    },
    {
        question: 'In Nederland ontstond er een ernstig tekort van een bepaalde grondstof. Welke grondstof was dit?',
        correctAnswer: 'Kool',
        type: 'open-ended'
    },
];

let currentQuestionIndex = -1;
let correctAnswers = 0;

function displayQuestion() {
    const questionElement = document.getElementById('question');
    const optionsContainer = document.getElementById('options');
    const feedbackContainer = document.getElementById('feedback');

    questionElement.textContent = `Question ${currentQuestionIndex + 1}: ${questions[currentQuestionIndex].question}`;

    if (questions[currentQuestionIndex].type === 'multiple-choice') {
        optionsContainer.innerHTML = '';
        for (const option of questions[currentQuestionIndex].options) {
            const button = document.createElement('button');
            button.textContent = option;
            button.addEventListener('click', () => checkAnswer(option));
            optionsContainer.appendChild(button);
        }
    } else if (questions[currentQuestionIndex].type === 'open-ended') {
        const answerInput = document.createElement('textarea');
        answerInput.id = 'open-question-answer';
        answerInput.setAttribute('placeholder', 'Type your answer here...');
        optionsContainer.innerHTML = ''; 
        optionsContainer.appendChild(answerInput);

        const submitButton = document.createElement('button');
        submitButton.textContent = 'Submit Answer';
        submitButton.id = 'open-question-submit-btn';
        submitButton.addEventListener('click', () => submitOpenAnswer());
        optionsContainer.appendChild(submitButton);
    }

    feedbackContainer.innerHTML = '';
    document.getElementById('next-btn').style.display = 'none';
}

function submitOpenAnswer() {
    const submittedAnswer = document.getElementById('open-question-answer');
    const correctAnswer = questions[currentQuestionIndex].correctAnswer;
    const feedbackContainer = document.getElementById('feedback');

    submittedAnswer.setAttribute('readonly', 'readonly');
    submittedAnswer.value = submittedAnswer.value || 'No answer provided';

    feedbackContainer.innerHTML = `<h2 class="correct-answer">Het juiste antwoord is ${correctAnswer}</h2>`;
    document.getElementById('open-question-submit-btn').style.display = 'none';

    const correctButton = document.createElement('button');
    const wrongButton = document.createElement('button');

    correctButton.textContent = 'Juist!';
    correctButton.id = 'correct-btn';
    correctButton.addEventListener('click', () => {
        correctAnswers++;
        nextQuestion();
    });

    wrongButton.textContent = 'onjuist...';
    wrongButton.id = 'wrong-btn';
    wrongButton.addEventListener('click', () => {
        nextQuestion();
    });

    feedbackContainer.appendChild(correctButton);
    feedbackContainer.appendChild(wrongButton);
}

function checkAnswer(selectedAnswer) {
    const correctAnswer = questions[currentQuestionIndex].correctAnswer;
    const feedbackContainer = document.getElementById('feedback');

    if (selectedAnswer === correctAnswer) {
        feedbackContainer.innerHTML = '<h2 class="correct">Juist!</h2>';
        correctAnswers++;
    } else {
        feedbackContainer.innerHTML = `<h2 class="wrong">Onjuist! Het juiste antwoord is ${correctAnswer}</h2>`;
    }

    document.getElementById('next-btn').style.display = 'block';
}

function nextQuestion() {
    currentQuestionIndex++;

    if (currentQuestionIndex < questions.length) {
        displayQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    const feedbackContainer = document.getElementById('feedback');
    feedbackContainer.innerHTML = `<h2>je hebt ${correctAnswers} van de ${questions.length} vragen juist beantwoord!</h2>`;
    document.getElementById('next-btn').style.display = 'none';
}


displayQuestion();