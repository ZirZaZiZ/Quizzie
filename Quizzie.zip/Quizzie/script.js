const questions = [
    {
        question: 'In welk jaartal begon de Eerste Wereldoorlog?',
        options: ['1914', '1916', '1918', '1920'],
        correctAnswer: '1914',
        type: 'multiple-choice'
    },
    {
        question: 'Welke moordaanslag was de aanleiding voor de Eerste Wereldoorlog?',
        options: ['Joseph Stalin', 'Franz Ferdinand', 'Sophie, Duchess of Honenberg', 'Prins Maximillian'],
        correctAnswer: 'Franz Ferdinand',
        type: 'multiple-choice'
    },
    {
        question: 'Welke geheime gemeenschap organiseerde de moordaanslag op het leven van Franz Ferdinand?',
        options: ['RozenKruisers', 'Bilderberg', 'Vrijmetselaars', 'De zwarte hand'], 
        correctAnswer: 'De zwarte hand',
        type: 'multiple-choice'
    },
    {
        question: 'Hoe heette de man verantwoordelijk voor het vermoorden van Franz Ferinand?',
        options: ['Gavrilo Princip', 'Willem van Oranje III', 'Leopold Berchtold', 'Dragutin Dimitrijevic'],
        correctAnswer: 'Gavrilo Princip',
        type: 'multiple-choice'
    },
    {
        question: 'Wat was de eerste oorlogsverklaring wat de kettingreactie in stand zetten tot WW1?',
        options: ['Duitsland op Frankrijk', 'Oostenrijk-Hongarije op Servie', 'Rusland op Frankrijk', 'Amerika op Duitsland'],
        correctAnswer: 'Oostenrijk-Hongarije op Servie',
        type: 'multiple-choice'
    },
    {
        question: 'In WW1 hadden allerlei landen een race om de beste wapens en soldaten te maken, hoe noemen we dit begrip?',
        options: ['Nationalisme', 'Militairisme', 'Wapenwedloop', 'Gevechtsgereedheid'],
        correctAnswer: 'Wapenwedloop',
        type: 'multiple-choice'
    },
    {
        question: 'Wat was de stand van Nederland in deze oorlog?',
        options: ['Geallieerd', 'Centraal', 'Beschermer van Belgie', 'Neutraal'],
        correctAnswer: 'Neutraal',
        type: 'multiple-choice'
    },
    {
        question: 'Na veel oorlogsverklaringen aan het begin van de Oorlog waren er twee Bondgenootschappen gevormd, hoe heette deze Bondgenootschappen?',
        options: ['Geallieerden en Centralen', 'Nato en Warschaupact', 'CSTO en UN', 'Westfront en Oostfront'],
        correctAnswer: 'Geallieerden en Centralen',
        type: 'multiple-choice'
    },
    {
        question: 'Hoe heette Duitsland Officieel in WW1?',
        options: ['Weimarrepubliek', 'Deutches kaisserreich', 'Duitsland', 'Drittes Reich'],
        correctAnswer: 'Deutches kaisserreich',
        type: 'multiple-choice'
    },
    {
        question: 'De auto van Franz Ferdinand nam tijdens een parade een verkeerde afslag en is daarna beschoten door Gavrilo Princip, op welke manier wou de Zwarte Hand groep eigenlijk de Prins vermoorden?',
        options: ['Een scherpschutter', 'Vegiftiging', 'Een handgranaat'], 
        correctAnswer: 'Een handgranaat',
        type: 'multiple-choice'
    },
    {
        question: 'Wat was de motivatie van de serviers om de moord op de prins te plegen?',
        correctAnswer: 'Servie een vrij land maken apart van oostenrijk-hongarije .',
        type: 'open-ended'
    },
    {
        question: 'Welke landen maakten deel uit van de geallieerden?',
        correctAnswer: 'Frankrijk, Groot-Brittanie, Rusland En Amerika.',
        type: 'open-ended'
    },
    {
        question: 'Welke landen maakten deel uit van de centralen?',
        correctAnswer: 'Oostenrijk-Hongarije, Duitsland, Ottomaanse rijk en bulgarije.',
        type: 'open-ended'
    },
    {
        question: 'In welk jaartal startte de Eerste Wereldoorlog?',
        correctAnswer: '1914',
        type: 'open-ended'
    },
    {
        question: 'Hoe was de economische staat van Nederland in WW1? licht je antwoord toe.',
        correctAnswer: 'Slecht, omdat de handel bijna volledig stop was gezet.',
        type: 'open-ended'
    },
];


let currentQuestionIndex = 0;
let correctAnswers = 0;

function displayQuestion() {
    const questionElement = document.getElementById('question');
    const optionsContainer = document.getElementById('options');
    const feedbackContainer = document.getElementById('feedback');

    questionElement.textContent = `Vraag ${currentQuestionIndex + 1}: ${questions[currentQuestionIndex].question}`;

    if (questions[currentQuestionIndex].type === 'multiple-choice') {
        optionsContainer.innerHTML = '';
        for (const option of questions[currentQuestionIndex].options) {
            const button = document.createElement('button');
            button.textContent = option;
            button.addEventListener('click', () => checkAnswer(option));
            optionsContainer.appendChild(button);
        }
    } else if (questions[currentQuestionIndex].type === 'open-ended') {
        const answerInput = document.createElement('textarea');
        answerInput.id = 'open-question-answer';
        answerInput.setAttribute('placeholder', 'Type your answer here...');
        optionsContainer.innerHTML = '';
        optionsContainer.appendChild(answerInput);

        const submitButton = document.createElement('button');
        submitButton.textContent = 'Submit Answer';
        submitButton.id = 'open-question-submit-btn';
        submitButton.addEventListener('click', () => submitOpenAnswer());
        optionsContainer.appendChild(submitButton);
    }

    feedbackContainer.innerHTML = '';
    document.getElementById('next-btn').style.display = 'none';
}

function submitOpenAnswer() {
    const submittedAnswer = document.getElementById('open-question-answer');
    const correctAnswer = questions[currentQuestionIndex].correctAnswer;
    const feedbackContainer = document.getElementById('feedback');

    submittedAnswer.setAttribute('readonly', 'readonly');
    submittedAnswer.value = submittedAnswer.value || 'No answer provided';

    feedbackContainer.innerHTML = `<h2 class="correct-answer">The correct answer is ${correctAnswer}</h2>`;
    document.getElementById('open-question-submit-btn').style.display = 'none';

    const correctButton = document.createElement('button');
    const wrongButton = document.createElement('button');

    correctButton.textContent = 'Correct';
    correctButton.id = 'correct-btn';
    correctButton.addEventListener('click', () => {
        correctAnswers++;
        nextQuestion();
    });

    wrongButton.textContent = 'Wrong';
    wrongButton.id = 'wrong-btn';
    wrongButton.addEventListener('click', () => {
        nextQuestion();
    });

    feedbackContainer.appendChild(correctButton);
    feedbackContainer.appendChild(wrongButton);
}

function checkAnswer(selectedAnswer) {
    const correctAnswer = questions[currentQuestionIndex].correctAnswer;
    const feedbackContainer = document.getElementById('feedback');

    if (selectedAnswer === correctAnswer) {
        feedbackContainer.innerHTML = '<h2 class="correct">Goed!</h2>';
        correctAnswers++;
    } else {
        feedbackContainer.innerHTML = `<h2 class="wrong">Fout, het juiste antwoord is: ${correctAnswer}</h2>`;
    }

    document.getElementById('next-btn').style.display = 'block';
}

function nextQuestion() {
    currentQuestionIndex++;

    if (currentQuestionIndex < questions.length) {
        displayQuestion();
    } else {
        showResult();
    }
}

function showResult() {
const quizContainer = document.getElementById('quiz-container');
quizContainer.innerHTML = ''; // Clear quiz container

const finishContainer = document.createElement('div');
finishContainer.classList.add('finish-container');
finishContainer.innerHTML = `<h2>Quiz Afgerond!</h2><p>Je hebt ${correctAnswers} van de ${questions.length} vragen correct beantwoord.</p>`;
quizContainer.appendChild(finishContainer);
}
displayQuestion();