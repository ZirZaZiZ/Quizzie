const questions = [
    {
        question: 'hoeveel slachtoffers telde de eerste wereldoorlog ongeveer?',
        options: ['20 miljoen', '30 miljoen', '40 miljoen', '50 miljoen'],
        correctAnswer: '20 miljoen',
        type: 'multiple-choice'
       
    },
    {
        question: 'Hoe heette het vredesverdrag dat na WO1 ondertekent is?',
        options: ['verdrag van Versailles', 'Verdrag van Andelot', 'Verdrag van Ribemont', 'Verdrag van Spiers'],
        correctAnswer: 'verdrag van Versailles',
        type: 'multiple-choice'
        
    },
    {
        question: 'Wat stond er NIET in dit verdrag?',
        options: ['Duitse militaire besprekingen moeten gecontroleerd worden', 'Duitsland moet veel geld betalen voor schade', 'het Duitse leger mag uit max. 100000 man bestaan', 'Duitsland moet grondgebied afstaan'],
        correctAnswer: 'Duitse militaire besprekingen moeten gecontroleerd worden',
        type: 'multiple-choice'
        
    },
    {
        question: 'Wat was een belangrijke vooruitgang in Nederland na aanleiding van WO1?',
        options: ['Homohuwelijk wordt legaal', 'NAVO wordt gevormt', 'Algemeen kiesrecht wordt ingevoerd', 'er kwam veel vooruitgang in de economie'],
        correctAnswer: 'Algemeen kiesrecht wordt ingevoerd',
        type: 'multiple-choice'
        
    },
    {
        question: 'Tegen het eind van WO1 was er een revolutionaire stemming. Wat was hier een gevolg van?',
        options: ['De voormalige Duitse keizer werd vermoord', 'De Russische tsaar werd vermoord', 'De koning van Frankrijk werd afgezet', 'De koningin van Nederland werd afgezet'],
        correctAnswer: 'De Russische tsaar werd vermoord',
        type: 'multiple-choice'
        
    },
    {
        question: 'De inflatie in Duitsland was verschrikkelijk in 1922. 1 dollar kostte namelijk…. ',
        options: ['5000 Mark', '10000 Mark', '20000 Mark', '25000 Mark'],
        correctAnswer: '20000 Mark',
        type: 'multiple-choice'
        
    },

    {
        question: 'Om de economische situatie te verbeteren werd er een nieuwe munt ingevoerd in duitsland. Hoe heette deze munt? ',
        options: ['Rentenmark', 'Kostenmark', 'Intermark', 'Uitermark'],
        correctAnswer: 'Rentenmark',
        type: 'multiple-choice'
        
    },
    {
        question: 'Na WO1 gebeurde de zogenaamde "beurskrach", wat hielt dit in?',
        options: ['Het was nu mogenlijk om te beleggen in aandelen', 'De beurs zag een enorme vooruitgang', 'Het was nu niet meer mogenlijk om te beleggen in aandelen', 'de beurs stortte in'],
        correctAnswer: 'de beurs stortte in',
        type: 'multiple-choice'
        
    },

    {
        question: 'Hoe heette het Amerikaanse plan om Duitsland terug overeind te helpen?',
        options: ['Darwinplan', 'Dawesplan', 'Dalesplan', 'Daysplan'],
        correctAnswer: 'Dawesplan',
        type: 'multiple-choice'
        
    },
    {
        question: 'in welk jaar begon de tweede wereldoorlog?',
        options: ['1937', '1938', '1939', '1940'],
        correctAnswer: '1939',
        type: 'multiple-choice'
    },
   
    {
        question: 'de uitvinding van de radio had een onbedoeld gevolg. waar werd het voor gebruikt?',
        correctAnswer: 'propaganda',
        type: 'open-ended'
    },

    {
        question: 'Welke ideologie nam de macht in Rusland na WO1?',
        correctAnswer: 'communisme',
        type: 'open-ended'
    },
    {
        question: 'Welke ideologie nam de macht in Duitsland na WO1?',
        correctAnswer: 'fascisme',
        type: 'open-ended'
    },
    {
        question: 'Na WO1 werd Duitsland een republiek. Hoe heette deze republiek?',
        correctAnswer: 'Weimarrepubliek',
        type: 'open-ended'
    },
    {
        question: 'In Nederland was er na WO1 een ernstig tekort aan een bepaalde grondstof. Welke grondstof was dit?',
        correctAnswer: 'kool',
        type: 'open-ended'
    },

]
let currentQuestionIndex = -1;
let correctAnswers = 0;

function displayQuestion() {
    const questionElement = document.getElementById('vraag');
    const optionsContainer = document.getElementById('options');
    const feedbackContainer = document.getElementById('feedback');

    questionElement.textContent = `vraag ${currentQuestionIndex + 1}: ${questions[currentQuestionIndex].question}`;

    if (questions[currentQuestionIndex].type === 'multiple-choice') {
        optionsContainer.innerHTML = '';
        for (const option of questions[currentQuestionIndex].options) {
            const button = document.createElement('button');
            button.textContent = option;
            button.addEventListener('click', () => checkAnswer(option));
            optionsContainer.appendChild(button);
        }
    } else if (questions[currentQuestionIndex].type === 'open-ended') {
        const answerInput = document.createElement('textarea');
        answerInput.id = 'open-question-answer';
        answerInput.setAttribute('placeholder', 'Type je antwoord hier.');
        optionsContainer.innerHTML = ''; 
        optionsContainer.appendChild(answerInput);

        const submitButton = document.createElement('button');
        submitButton.textContent = 'bevestig antwoord';
        submitButton.id = 'open-question-submit-btn';
        submitButton.addEventListener('click', () => submitOpenAnswer());
        optionsContainer.appendChild(submitButton);
    }

    feedbackContainer.innerHTML = '';
    document.getElementById('next-btn').style.display = 'none';
}

function submitOpenAnswer() {
    const submittedAnswer = document.getElementById('open-question-answer');
    const correctAnswer = questions[currentQuestionIndex].correctAnswer;
    const feedbackContainer = document.getElementById('feedback');

    submittedAnswer.setAttribute('readonly', 'readonly');
    submittedAnswer.value = submittedAnswer.value || 'geen antwoord ingevult.';

    feedbackContainer.innerHTML = `<h2 class="correct-answer">Het juiste antwoord is ${correctAnswer}</h2>`;
    document.getElementById('open-question-submit-btn').style.display = 'none';

    const correctButton = document.createElement('button');
    const wrongButton = document.createElement('button');

    correctButton.textContent = 'Juist!';
    correctButton.id = 'correct-btn';
    correctButton.addEventListener('click', () => {
        correctAnswers++;
        nextQuestion();
    });

    wrongButton.textContent = 'Onjuist....';
    wrongButton.id = 'wrong-btn';
    wrongButton.addEventListener('click', () => {
        nextQuestion();
    });

    feedbackContainer.appendChild(correctButton);
    feedbackContainer.appendChild(wrongButton);
}

function checkAnswer(selectedAnswer) {
    const correctAnswer = questions[currentQuestionIndex].correctAnswer;
    const feedbackContainer = document.getElementById('feedback');

    if (selectedAnswer === correctAnswer) {
        feedbackContainer.innerHTML = '<h2 class="correct">Juist!</h2>';
        correctAnswers++;
    } else {
        feedbackContainer.innerHTML = `<h2 class="wrong">Onjuist! het juiste antwoord is ${correctAnswer}</h2>`;
    }

    document.getElementById('next-btn').style.display = 'block';
}

function nextQuestion() {
    currentQuestionIndex++;

    if (currentQuestionIndex < questions.length) {
        displayQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    const feedbackContainer = document.getElementById('feedback');

    const totalQuestions = questions.length;
    
    if (correctAnswers > 14) {
        feedbackContainer.innerHTML = `<h2>Gefeliciteerd! Je hebt alle vragen juist beantwoord!</h2>`;
    } else if (correctAnswers > 10) {
        feedbackContainer.innerHTML = `<h2>Goed gedaan! ${correctAnswers} van de 15 vragen juist! </h2>`;
    } else if (correctAnswers > 5) {
        feedbackContainer.innerHTML = `<h2>niet slecht.. Je hebt ${correctAnswers} van de 15 vragen juist.</h2>`;
    } else {
        feedbackContainer.innerHTML = `<h2>Helaas! Je hebt maar ${correctAnswers} van de 15 vragen juist beantwoord.</h2>`;
    }
    document.getElementById('next-btn').style.display = 'none';
}

displayQuestion();